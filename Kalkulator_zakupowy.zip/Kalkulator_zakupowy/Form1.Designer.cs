﻿namespace Kalkulator_zakupowy
{
    partial class FormShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdd = new System.Windows.Forms.Button();
            this.labelAllCost = new System.Windows.Forms.Label();
            this.textBoxAllCost = new System.Windows.Forms.TextBox();
            this.flowLayoutPanelShop = new System.Windows.Forms.FlowLayoutPanel();
            this.SuspendLayout();
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(12, 12);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd.TabIndex = 0;
            this.buttonAdd.Text = "Dodaj";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // labelAllCost
            // 
            this.labelAllCost.AutoSize = true;
            this.labelAllCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.labelAllCost.Location = new System.Drawing.Point(187, 17);
            this.labelAllCost.Name = "labelAllCost";
            this.labelAllCost.Size = new System.Drawing.Size(59, 13);
            this.labelAllCost.TabIndex = 1;
            this.labelAllCost.Text = "Do zapłaty";
            // 
            // textBoxAllCost
            // 
            this.textBoxAllCost.Enabled = false;
            this.textBoxAllCost.Location = new System.Drawing.Point(252, 14);
            this.textBoxAllCost.Name = "textBoxAllCost";
            this.textBoxAllCost.Size = new System.Drawing.Size(118, 20);
            this.textBoxAllCost.TabIndex = 2;
            // 
            // flowLayoutPanelShop
            // 
            this.flowLayoutPanelShop.AutoSize = true;
            this.flowLayoutPanelShop.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanelShop.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanelShop.Location = new System.Drawing.Point(12, 41);
            this.flowLayoutPanelShop.Name = "flowLayoutPanelShop";
            this.flowLayoutPanelShop.Size = new System.Drawing.Size(0, 0);
            this.flowLayoutPanelShop.TabIndex = 3;
            // 
            // FormShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(530, 72);
            this.Controls.Add(this.flowLayoutPanelShop);
            this.Controls.Add(this.textBoxAllCost);
            this.Controls.Add(this.labelAllCost);
            this.Controls.Add(this.buttonAdd);
            this.Name = "FormShop";
            this.Text = "Kalkulator zakupowy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Label labelAllCost;
        private System.Windows.Forms.TextBox textBoxAllCost;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelShop;
    }
}

