﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kalkulator_zakupowy
{
    public partial class UserControlProduct : UserControl
    {
        public delegate void UserControlProductAction(UserControlProduct p);
        public event UserControlProductAction ProductDelete;
        public event UserControlProductAction ProductChange;

        private Product myProduct;

        public Product MyProduct { get => myProduct; set => myProduct = value; }

        public UserControlProduct(Product p)
        {
            InitializeComponent();

            MyProduct = p;

            textBoxName.Text = p.Name;
            numericUpDownCost.Value = (decimal)p.Cost;
            numericUpDownCount.Value = p.Count;

            textBoxAllCostProduct.Text = ((float)numericUpDownCost.Value * (float)numericUpDownCount.Value).ToString();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            ProductDelete?.Invoke(this);
        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {
            myProduct.Name = textBoxName.Text;
            ProductChange?.Invoke(this);
        }

        private void numericUpDownCost_ValueChanged(object sender, EventArgs e)
        {
            myProduct.Cost = (float)numericUpDownCost.Value;
            textBoxAllCostProduct.Text = ((float)numericUpDownCost.Value * (float)numericUpDownCount.Value).ToString();
            ProductChange?.Invoke(this);
        }

        private void numericUpDownCount_ValueChanged(object sender, EventArgs e)
        {
            myProduct.Count = (int)numericUpDownCount.Value;
            textBoxAllCostProduct.Text = ((float)numericUpDownCost.Value * (float)numericUpDownCount.Value).ToString();
            ProductChange?.Invoke(this);
        }
    }
}
