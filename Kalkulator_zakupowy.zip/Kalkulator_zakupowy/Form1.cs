﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kalkulator_zakupowy
{
    public partial class FormShop : Form
    {
        DBDataContext db = new DBDataContext();
        private float costOfProducts;

        public float CostOfProducts { get => costOfProducts; set => costOfProducts = value; }

        public FormShop()
        {
            InitializeComponent();

            foreach(Product p in db.Products) 
            { 
                UserControlProduct ucProduct = new UserControlProduct(p);
                ucProduct.ProductChange += ProductChange;
                ucProduct.ProductDelete += ProductDelete;
                flowLayoutPanelShop.Controls.Add(ucProduct);
                CostOfProducts += (float)p.Cost * p.Count;
                textBoxAllCost.Text = CostOfProducts.ToString();
            }
        }

        private void ProductDelete(UserControlProduct p)
        {
            CostOfProducts -= p.MyProduct.Count * (float)p.MyProduct.Cost;
            textBoxAllCost.Text = CostOfProducts.ToString();
            flowLayoutPanelShop.Controls.Remove(p);
            db.Products.DeleteOnSubmit(p.MyProduct);
            db.SubmitChanges();
        }

        private void ProductChange(UserControlProduct p)
        {
            CostOfProducts += (float)p.MyProduct.Cost * p.MyProduct.Count;
            textBoxAllCost.Text = CostOfProducts.ToString();
            db.SubmitChanges();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Product newProduct = new Product();
            newProduct.Name = "";
            newProduct.Cost = 0.00;
            newProduct.Count = 0;
            UserControlProduct product = new UserControlProduct(newProduct);
            product.ProductChange += ProductChange;
            product.ProductDelete += ProductDelete;
            flowLayoutPanelShop.Controls.Add(product);
            CostOfProducts += newProduct.Count * (float)newProduct.Cost;
            textBoxAllCost.Text = CostOfProducts.ToString();
            db.Products.InsertOnSubmit(newProduct);
            db.SubmitChanges();
        }
    }
}
